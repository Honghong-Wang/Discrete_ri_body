function u=Fun_Friction_Coefficient(beta,theta_0)
global sec seg
u=zeros(2,2*sec*seg+1);
%% from disk D_0 to disk D_2i
for k=1:2*(sec*seg+1)
    if k==1
        u(1,k)=Fun_u(theta_0);
        u(2,k)=Fun_u(beta(1)/2);%u(xx,2i)
    elseif k==2*(sec*seg+1)
        u(1,k)=Fun_u(beta(k-1)/2);
        u(2,k)=0;%u(xx,2i)
    else
        u(1,k)=Fun_u(beta(k-1)/2);
        u(2,k)=Fun_u(beta(k)/2);
    end
end
end