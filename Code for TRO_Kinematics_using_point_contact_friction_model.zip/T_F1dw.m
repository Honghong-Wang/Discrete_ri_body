function F=T_F1dw(beta,num_cable)
%sec：i
%frame system：O_2（i-1）
global h theta_cable r_cable theta_bevel;
%% bending plane 2i-1：
r_2D=abs(r_cable(num_cable)*cos(theta_cable(num_cable)));
Hole_Bottom=[-h/2+r_2D*tan(theta_bevel) r_cable(num_cable)*sin(theta_cable(num_cable)) -r_cable(num_cable)*cos(theta_cable(num_cable)) 1]';
temp=Trans0_1(beta)*Hole_Bottom;
F=[temp(1) temp(2) temp(3)];
end