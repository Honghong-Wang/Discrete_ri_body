function F=Fun_Force_of_Cable_EndClear(F_Cable)
global sec seg Cable_Num_of_Sec Num_Cable;
F=zeros(Num_Cable,2*sec*seg+1);
for num=1:Num_Cable
    for i=1:2*seg*(floor((num-1)/Cable_Num_of_Sec)+1)
        F(num,i)=F_Cable(num,i);
    end
end
end