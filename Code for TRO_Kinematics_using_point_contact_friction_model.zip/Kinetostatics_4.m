function F=Kinetostatics_4(beta,F_Cable,record,beta1)
%% Consider Joint Constraint
% clearvars -except beta F_Cable;
global sec seg Cable_Num_of_Sec h E Iz g L Num_Cable M_Disk M_Joint;
global F_Load M_Load
%% Kinematics:
F_D2i_Cj=cell(Num_Cable,1);
F_D2i_Cj_R=cell(Num_Cable,1);
F_D2i_Cj_L=cell(Num_Cable,1);
M_F_D2i_Cj=cell(Num_Cable,1);
%--------------------------------------------------------------------------
F_D2i_1_Cj=cell(Num_Cable,1);
F_D2i_1_Cj_R=cell(Num_Cable,1);
F_D2i_1_Cj_L=cell(Num_Cable,1);
M_F_D2i_1_Cj=cell(Num_Cable,1);
%--------------------------------------------------------------------------
F_D=zeros(3,2*sec*seg+1);
M_D=zeros(3,2*sec*seg+1);
T_Joint=[1 0 0 -h/2;
         0 1 0 0;
         0 0 1 0;
         0 0 0 1];
%% 
beta2=Fun_Beta_Add(beta,record,beta1);
for i=(sec*seg):-1:1
    if i==1
        Trans_pre=eye(4);
    else
        Trans_pre=eye(4);
        for j=1:(i-1)
            Trans_pre=Trans_pre*Trans0_1(beta2(2*j-1))*Trans1_2(beta2(2*j));
        end
    end
    Trans_now_0_1=Trans0_1(beta2(2*i-1));
    Trans_now_1_2=Trans1_2(beta2(2*i));
%% Kinetostatics：
%% Disk：2i；Frame system：O_2i-1
    %% Actuating Forces:
    %F_D2i_Cj:
    if mod(i,seg)==0
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Cable_Num_of_Sec*i/seg
            F_D2i_Cj_R{num}=[0 0 0 0]';
            F_D2i_Cj_L{num}=-F_Cable(num,2*i)*Vector2(beta2(2*i),num)/modvec2(beta2(2*i),num);
            F_D2i_Cj{num}=F_D2i_Cj_L{num};
            %------------------------------------------------------------------
            M_F_D2i_Cj{num}=cross(T_F2dw(beta2(2*i),num),[F_D2i_Cj_L{num}(1) F_D2i_Cj_L{num}(2) F_D2i_Cj_L{num}(3)]);
        end
        if i==sec*seg
            loopCircular;
        else
            for num2=Cable_Num_of_Sec*i/seg+1:Num_Cable
                F_D2i_Cj_R{num2}=Trans_now_1_2*F_Cable(num2,2*i+1)*Vector1(beta2(2*i+1),num2)/modvec1(beta2(2*i+1),num2);
                F_D2i_Cj_L{num2}=-F_Cable(num2,2*i)*Vector2(beta2(2*i),num2)/modvec2(beta2(2*i),num2);
                F_D2i_Cj{num2}=F_D2i_Cj_R{num2}+ F_D2i_Cj_L{num2};
                %------------------------------------------------------------------
                M_F_D2i_Cj{num2}=cross(T_F2up(beta2(2*i),num2),[F_D2i_Cj_R{num2}(1) F_D2i_Cj_R{num2}(2) F_D2i_Cj_R{num2}(3)])+cross(T_F2dw(beta2(2*i),num2),[F_D2i_Cj_L{num2}(1) F_D2i_Cj_L{num2}(2) F_D2i_Cj_L{num2}(3)]);
            end
        end
    else
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
            F_D2i_Cj_R{num}=Trans_now_1_2*F_Cable(num,2*i+1)*Vector1(beta2(2*i+1),num)/modvec1(beta2(2*i+1),num);
            F_D2i_Cj_L{num}=-F_Cable(num,2*i)*Vector2(beta2(2*i),num)/modvec2(beta2(2*i),num);
            F_D2i_Cj{num}=F_D2i_Cj_R{num}+ F_D2i_Cj_L{num};
            %------------------------------------------------------------------
            M_F_D2i_Cj{num}=cross(T_F2up(beta2(2*i),num),[F_D2i_Cj_R{num}(1) F_D2i_Cj_R{num}(2) F_D2i_Cj_R{num}(3)])+cross(T_F2dw(beta2(2*i),num),[F_D2i_Cj_L{num}(1) F_D2i_Cj_L{num}(2) F_D2i_Cj_L{num}(3)]);
        end
    end
    F_D2i_C=zeros(1,4);
    M_F_D2i_C=zeros(1,3);
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
        F_D2i_C=F_D2i_C+F_D2i_Cj{num};
        M_F_D2i_C=M_F_D2i_C+M_F_D2i_Cj{num};
    end
    %% Gravity:
    G_D2i=(Trans_pre*Trans_now_0_1)\[0 -M_Disk(1,2*i)*g 0 0]';
    %----------------------------------------------------------------------
    M_G_D2i=cross([Trans_now_1_2(1,4) Trans_now_1_2(2,4) Trans_now_1_2(3,4)],[G_D2i(1) G_D2i(2) G_D2i(3)]);
    %% Joint:
    G_J2i=(Trans_pre*Trans_now_0_1)\[0 -M_Joint(1,2*i)*g 0 0]';
    %----------------------------------------------------------------------
    T_Joint_temp=Trans_now_1_2*T_Joint;
    M_J_D2i=cross([T_Joint_temp(1,4) T_Joint_temp(2,4) T_Joint_temp(3,4)],[G_J2i(1) G_J2i(2) G_J2i(3)]);
    %% External Force:
    F_Load_D2i=(Trans_pre*Trans_now_0_1)\[F_Load(1,2*i) F_Load(2,2*i) F_Load(3,2*i) 0]';
    %----------------------------------------------------------------------
    M_F_Load_D2i=cross([Trans_now_1_2(1,4) Trans_now_1_2(2,4) Trans_now_1_2(3,4)],[F_Load_D2i(1) F_Load_D2i(2) F_Load_D2i(3)]);
    %
    M_M_Load_D2i=(Trans_pre*Trans_now_0_1)\[M_Load(1,2*i) M_Load(2,2*i) M_Load(3,2*i) 0]';
    %%
    F_D2iD=Trans_now_1_2*[F_D(1,2*i+1) F_D(2,2*i+1) F_D(3,2*i+1) 0]';
    %----------------------------------------------------------------------
    M_F_D2iD=cross([Trans_now_1_2(1,4) Trans_now_1_2(2,4) Trans_now_1_2(3,4)],[F_D2iD(1) F_D2iD(2) F_D2iD(3)]);
    %
    M_D_temp2=Trans_now_1_2*[M_D(1,2*i+1) M_D(2,2*i+1) M_D(3,2*i+1) 0]';
    %% Lumped：
    F_D2i=F_D2i_C+G_D2i+G_J2i+F_Load_D2i+F_D2iD;
    F_D(1,2*i)=F_D2i(1,1); F_D(2,2*i)=F_D2i(2,1); F_D(3,2*i)=F_D2i(3,1);
    %----------------------------------------------------------------------
    M_D2i=M_F_D2i_C+M_G_D2i+M_J_D2i+M_F_Load_D2i+M_F_D2iD+[M_M_Load_D2i(1) M_M_Load_D2i(2) M_M_Load_D2i(3)]+[M_D_temp2(1,1) M_D_temp2(2,1) M_D_temp2(3,1)];
    M_D(1,2*i)=M_D2i(1,1);M_D(2,2*i)=M_D2i(1,2);M_D(3,2*i)=M_D2i(1,3);
%% Disk：2i-1；Frame system：O_2(i-1)  
    %% Actuating Forces:
    %F_D2i_1_Cj:
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
        F_D2i_1_Cj_R{num}=Trans_now_0_1*F_Cable(num,2*i)*Vector2(beta2(2*i),num)/modvec2(beta2(2*i),num);
        F_D2i_1_Cj_L{num}=-F_Cable(num,2*i-1)*Vector1(beta2(2*i-1),num)/modvec1(beta2(2*i-1),num);
        F_D2i_1_Cj{num}=F_D2i_1_Cj_R{num}+ F_D2i_1_Cj_L{num};
        %------------------------------------------------------------------
        M_F_D2i_1_Cj{num}=cross(T_F1up(beta2(2*i-1),num),[F_D2i_1_Cj_R{num}(1) F_D2i_1_Cj_R{num}(2) F_D2i_1_Cj_R{num}(3)])+cross(T_F1dw(beta2(2*i-1),num),[F_D2i_1_Cj_L{num}(1) F_D2i_1_Cj_L{num}(2) F_D2i_1_Cj_L{num}(3)]);
    end
    F_D2i_1_C=zeros(1,4);
    M_F_D2i_1_C=zeros(1,3);
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
        F_D2i_1_C=F_D2i_1_C+F_D2i_1_Cj{num};
        M_F_D2i_1_C=M_F_D2i_1_C+M_F_D2i_1_Cj{num};
    end
    %% Gravity:
    G_D2i_1=Trans_pre\[0 -M_Disk(1,2*i-1)*g 0 0]';
    %----------------------------------------------------------------------
    M_G_D2i_1=cross([Trans_now_0_1(1,4) Trans_now_0_1(2,4) Trans_now_0_1(3,4)],[G_D2i_1(1) G_D2i_1(2) G_D2i_1(3)]);
    %% Joint:
    G_J2i_1=Trans_pre\[0 -M_Joint(1,2*i-1)*g 0 0]';
    %----------------------------------------------------------------------
    T_Joint_temp=Trans_now_0_1*T_Joint;
    M_J_D2i_1=cross([T_Joint_temp(1,4) T_Joint_temp(2,4) T_Joint_temp(3,4)],[G_J2i_1(1) G_J2i_1(2) G_J2i_1(3)]);
    %% External Force:
    F_Load_D2i_1=Trans_pre\[F_Load(1,2*i-1) F_Load(2,2*i-1) F_Load(3,2*i-1) 0]';
    %----------------------------------------------------------------------
    M_F_Load_D2i_1=cross([Trans_now_0_1(1,4) Trans_now_0_1(2,4) Trans_now_0_1(3,4)],[F_Load_D2i_1(1) F_Load_D2i_1(2) F_Load_D2i_1(3)]);
    % 
    M_M_Load_D2i_1=Trans_pre\[M_Load(1,2*i-1) M_Load(2,2*i-1) M_Load(3,2*i-1) 0]';
    %%
    %F_D(:,2i):
    F_D2i_1D=Trans_now_0_1*[F_D(1,2*i) F_D(2,2*i) F_D(3,2*i) 0]';
    %----------------------------------------------------------------------
    M_F_D2i_1D=cross([Trans_now_0_1(1,4) Trans_now_0_1(2,4) Trans_now_0_1(3,4)],[F_D2i_1D(1) F_D2i_1D(2) F_D2i_1D(3)]);
    % 
    M_D_temp1=Trans_now_0_1*[M_D(1,2*i) M_D(2,2*i) M_D(3,2*i) 0]';
    %% Lumped：
    F_D2i_1=F_D2i_1_C+G_D2i_1+G_J2i_1+F_Load_D2i_1+F_D2i_1D;
    F_D(1,2*i-1)=F_D2i_1(1,1); F_D(2,2*i-1)=F_D2i_1(2,1); F_D(3,2*i-1)=F_D2i_1(3,1);
    %----------------------------------------------------------------------
    M_D2i_1=M_F_D2i_1_C+M_G_D2i_1+M_J_D2i_1+M_F_Load_D2i_1+M_F_D2i_1D+[M_M_Load_D2i_1(1) M_M_Load_D2i_1(2) M_M_Load_D2i_1(3)]+[M_D_temp1(1,1) M_D_temp1(2,1) M_D_temp1(3,1)];
    M_D(1,2*i-1)=M_D2i_1(1,1);M_D(2,2*i-1)=M_D2i_1(1,2);M_D(3,2*i-1)=M_D2i_1(1,3);
end
for ii=2*sec*seg:-1:1
    Lia=ismember(ii,record);
    if Lia
        F(1,ii)=0;
    else
        F(1,ii)=M_D(3,ii)-2*beta2(ii)*E*Iz/L;
    end  
end
end