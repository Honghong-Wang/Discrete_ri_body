function F=Fun_Sum_Cable(Length)%：Cable_Length
global sec seg Num_Cable
%for Sum_D_Cable(1,k)
F=zeros(Num_Cable,2*sec*seg);
%Sum_D_Cable(num,k)
for num=1:Num_Cable
    for k=2*sec*seg:-1:1
        if k==2*sec*seg
            F(num,k)=Length(num,k);
        else
            F(num,k)=F(num,k+1)+Length(num,k);
        end
    end
end
end