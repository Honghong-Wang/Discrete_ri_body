function F=Vector2(beta,num_cable)
global h theta_cable r_cable theta_bevel;
r_2D=abs(r_cable(num_cable)*sin(theta_cable(num_cable)));
%% disk 2i-1：
Hole_Top=[h/2-r_2D*tan(theta_bevel) r_cable(num_cable)*sin(theta_cable(num_cable)) -r_cable(num_cable)*cos(theta_cable(num_cable)) 1]';
%% disk 2i：
Hole_Bottom=[-h/2+r_2D*tan(theta_bevel) r_cable(num_cable)*cos(theta_cable(num_cable)) r_cable(num_cable)*sin(theta_cable(num_cable)) 1]';
%%
F=Trans1_2(beta)*Hole_Bottom-Hole_Top;
end