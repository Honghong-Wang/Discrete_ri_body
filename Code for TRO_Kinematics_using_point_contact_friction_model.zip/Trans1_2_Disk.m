function T=Trans1_2_Disk(beta)
global h;
if beta==0
    T=[1 0 0 1000*h;
       0 0 1 0;
       0 -1 0 0;
       0 0 0 1];
else
    T1=[1 0 0 1000*h/2;
        0 1 0 0;
        0 0 1 0;
        0 0 0 1];
    T2=[cos(beta) -sin(beta) 0 0;
        sin(beta) cos(beta) 0 0;
        0 0 1 0;
        0 0 0 1];
    T3=[1 0 0 1000*h/2;
        0 0 1 0;
        0 -1 0 0;
        0 0 0 1];
    T=T1*T2*T3;
end 
end