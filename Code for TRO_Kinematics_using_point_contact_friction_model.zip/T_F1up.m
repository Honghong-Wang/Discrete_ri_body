function F=T_F1up(beta,num_cable)
global h theta_cable r_cable theta_bevel;
%% bending plane 2i-1：
r_2D=abs(r_cable(num_cable)*cos(theta_cable(num_cable)));
Hole_Top=[h/2-r_2D*tan(theta_bevel) r_cable(num_cable)*sin(theta_cable(num_cable)) -r_cable(num_cable)*cos(theta_cable(num_cable)) 1]';
temp=Trans0_1(beta)*Hole_Top;
F=[temp(1) temp(2) temp(3)];
end