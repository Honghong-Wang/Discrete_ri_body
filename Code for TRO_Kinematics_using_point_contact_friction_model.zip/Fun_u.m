function F=Fun_u(beta)
%% friction coefficient，u（theta，0）
a=-5.2065;
b=2.5267;
c=0.1823;
F=a*beta^2+b*beta+c;
end
