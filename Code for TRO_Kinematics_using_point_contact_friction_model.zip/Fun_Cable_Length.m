function F=Fun_Cable_Length(beta)
%calculate Cable_Length
%%
global sec seg Num_Cable Cable_Num_of_Sec theta_cable r_cable theta_bevel;
F=zeros(Num_Cable,2*sec*seg);
for i=1:sec*seg
%cable length variation---------------------------
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
        %-----------disk 2i-----------
        F(num,2*i-1)=2*r_cable(num)*abs(cos(theta_cable(num)))*(sin(theta_bevel-sign(cos(theta_cable(num)))*beta(2*i-1)/2)-sin(theta_bevel))/cos(theta_bevel);
        F(num,2*i)=2*r_cable(num)*abs(sin(theta_cable(num)))*(sin(theta_bevel-sign(sin(theta_cable(num)))*beta(2*i)/2)-sin(theta_bevel))/cos(theta_bevel);
    end
end
end