function [F,record]=Fun_Beta_Boundary(beta)
%% judge whether the angle is out of range
global beta_boundary
size_beta=size(beta);
F=zeros(size_beta(1),size_beta(2));
record=[];
num=1;
for i=1:size_beta(1)
    for j=1:size_beta(2)
        if beta(i,j)>=beta_boundary
            F(i,j)=beta_boundary;
            record(num)=j;
            num=num+1;
        elseif beta(i,j)<=-beta_boundary
            F(i,j)=-beta_boundary;
            record(num)=j;
            num=num+1;
        else
            F(i,j)=beta(i,j);
        end
    end
end
if num==1
    record=[0];
end
end