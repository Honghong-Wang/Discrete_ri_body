function F=Fun_F_Cable_4(F_Cable,beta)
global sec seg Cable_Num_of_Sec Num_Cable Cable_Length Sum_D_Cable;
global theta_cable r_cable F_Sensor
%% Cable Length:
Cable_Length=Fun_Cable_Length(beta);
Sum_D_Cable=Fun_Sum_Cable(Cable_Length);
%% Friction Coefficient: 
theta_0=12.944/180*pi;
delta_0=65.5/1000;
u=Fun_Friction_Coefficient(beta,theta_0);
%note: there is an angle the between tendon and the end of the manipulator
%%
F_Dn_Cj_R=cell(Num_Cable,2*sec*seg);
F_Dn_Cj_L=cell(Num_Cable,2*sec*seg);
F_N_Dn_Cj_R=cell(Num_Cable,2*sec*seg);
F_N_Dn_Cj_L=cell(Num_Cable,2*sec*seg);
F_f_Dn_Cj_R=cell(Num_Cable,2*sec*seg);
F_f_Dn_Cj_L=cell(Num_Cable,2*sec*seg);
%--------------------------------------------------------------------------
F_D0_Cj_R=cell(Num_Cable,1);
F_N_D0_Cj_R=cell(Num_Cable,1);
F_f_D0_Cj_R=cell(Num_Cable,1);
F_D0_Cj_L=cell(Num_Cable,1);
F_N_D0_Cj_L=cell(Num_Cable,1);
F_f_D0_Cj_L=cell(Num_Cable,1);
%% Actuating Force:
for num=1:Num_Cable
    F_D0_Cj_R{num}=F_Cable(num,1)*Vector1(beta(1),num)/modvec1(beta(1),num);
    F_N_D0_Cj_R{num}=F_D0_Cj_R{num}'.*[0 1 1 0];
    F_f_D0_Cj_R{num}=[u(2,1)*norm(F_N_D0_Cj_R{num},2) 0 0 0]';
    vec_0=[delta_0/cos(theta_0) r_cable(num)*cos(theta_cable(num)) r_cable(num)*sin(theta_cable(num)) 0]';
    F_D0_Cj_L{num}=-F_Sensor(num)*vec_0/norm(vec_0,2);
    F_N_D0_Cj_L{num}=F_D0_Cj_L{num}'.*[0 1 1 0];
    F_f_D0_Cj_L{num}=[u(1,1)*norm(F_N_D0_Cj_L{num},2) 0 0 0]';
end
%--------------------------------------------------------------------------
for i=(sec*seg):-1:1
    if i==1
        Trans_pre=eye(4);
    else
        Trans_pre=eye(4);
        for j=1:(i-1)
            Trans_pre=Trans_pre*Trans0_1(beta(2*j-1))*Trans1_2(beta(2*j));
        end
    end
    Trans_now_0_1=Trans0_1(beta(2*i-1));
    Trans_now_1_2=Trans1_2(beta(2*i));
    %% Disk：2i；Frame System：O_2i-1
    %% Actuating Forces:
    %F_D2i_Cj:
    if mod(i,seg)==0
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Cable_Num_of_Sec*i/seg
            F_Dn_Cj_R{num,2*i}=[0 0 0 0]';
            F_Dn_Cj_L{num,2*i}=-F_Cable(num,2*i)*Vector2(beta(2*i),num)/modvec2(beta(2*i),num);
        end
        if i==sec*seg
            loopCircular;
        else
            for num2=Cable_Num_of_Sec*i/seg:Num_Cable
                F_Dn_Cj_R{num2,2*i}=Trans_now_1_2*F_Cable(num2,2*i+1)*Vector1(beta(2*i+1),num2)/modvec1(beta(2*i+1),num2);
                F_Dn_Cj_L{num2,2*i}=-F_Cable(num2,2*i)*Vector2(beta(2*i),num2)/modvec2(beta(2*i),num2);
            end
        end
    else
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
            F_Dn_Cj_R{num,2*i}=Trans_now_1_2*F_Cable(num,2*i+1)*Vector1(beta(2*i+1),num)/modvec1(beta(2*i+1),num);
            F_Dn_Cj_L{num,2*i}=-F_Cable(num,2*i)*Vector2(beta(2*i),num)/modvec2(beta(2*i),num);
        end
    end
  %% Disk：2i-1；Frame System：O_2(i-1)  
    %% Actuating Forces:
    %F_D2i_1_Cj:
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
        F_Dn_Cj_R{num,2*i-1}=Trans_now_0_1*F_Cable(num,2*i)*Vector2(beta(2*i),num)/modvec2(beta(2*i),num);
        F_Dn_Cj_L{num,2*i-1}=-F_Cable(num,2*i-1)*Vector1(beta(2*i-1),num)/modvec1(beta(2*i-1),num);
    end
    %% Friction Force:
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable  
        F_N_Dn_Cj_R{num,2*i}=(Trans_now_1_2\F_Dn_Cj_R{num,2*i})'.*[0 1 1 0];
        F_f_Dn_Cj_R{num,2*i}=[u(2,2*i+1)*norm(F_N_Dn_Cj_R{num,2*i},2) 0 0 0]';  %disk 2i
        F_N_Dn_Cj_R{num,2*i-1}=(Trans_now_0_1\F_Dn_Cj_R{num,2*i-1})'.*[0 1 1 0];
        F_f_Dn_Cj_R{num,2*i-1}=[u(2,2*i)*norm(F_N_Dn_Cj_R{num,2*i-1},2) 0 0 0]';  %disk 2i-1
        %------------------------------------------------------------------
        F_N_Dn_Cj_L{num,2*i}=(Trans_now_1_2\F_Dn_Cj_L{num,2*i})'.*[0 1 1 0];
        F_f_Dn_Cj_L{num,2*i}=[u(1,2*i+1)*norm(F_N_Dn_Cj_L{num,2*i},2) 0 0 0]';  %disk 2i
        F_N_Dn_Cj_L{num,2*i-1}=(Trans_now_0_1\F_Dn_Cj_L{num,2*i-1})'.*[0 1 1 0];
        F_f_Dn_Cj_L{num,2*i-1}=[u(1,2*i)*norm(F_N_Dn_Cj_L{num,2*i-1},2) 0 0 0]';  %disk 2i-1
    end
end
%% Friction Direction:
for i=sec*seg:-1:1
    for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
       if Sum_D_Cable(num,2*i)<0
           F(num,2*i)=-F_Cable(num,2*i)+F_Cable(num,2*i-1)-F_f_Dn_Cj_R{num,2*i-1}(1)-F_f_Dn_Cj_L{num,2*i-1}(1);
       elseif Sum_D_Cable(num,2*i)>0
           F(num,2*i)=-F_Cable(num,2*i)+F_Cable(num,2*i-1)+F_f_Dn_Cj_R{num,2*i-1}(1)+F_f_Dn_Cj_L{num,2*i-1}(1);
       else
           F(num,2*i)=-F_Cable(num,2*i)+F_Cable(num,2*i-1);
       end
    end
    if mod(i,seg)==0
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Cable_Num_of_Sec*i/seg
            if Sum_D_Cable(num,1)<0
                F(num,1)=-F_Cable(num,1)+F_Sensor(num)-F_f_D0_Cj_R{num}(1)-F_f_D0_Cj_L{num}(1);
            elseif Sum_D_Cable(num,1)>0
                F(num,1)=-F_Cable(num,1)+F_Sensor(num)+F_f_D0_Cj_R{num}(1)+F_f_D0_Cj_L{num}(1);
            else
                F(num,1)=-F_Cable(num,1)+F_Sensor(num);
            end
        end
        if i==sec*seg
            loopCircular;
        else
            for num2=Cable_Num_of_Sec*i/seg+1:Num_Cable
                if Sum_D_Cable(num2,2*i+1)<0
                    F(num2,2*i+1)=-F_Cable(num2,2*i+1)+F_Cable(num2,2*i)-F_f_Dn_Cj_R{num2,2*i}(1)-F_f_Dn_Cj_L{num2,2*i}(1);
                elseif Sum_D_Cable(num,2*+1)>0
                    F(num2,2*i+1)=-F_Cable(num2,2*i+1)+F_Cable(num2,2*i)+F_f_Dn_Cj_R{num2,2*i}(1)+F_f_Dn_Cj_L{num2,2*i}(1);
                else
                    F(num2,2*i+1)=-F_Cable(num2,2*i+1)+F_Cable(num2,2*i);
                end
            end
        end
    else
        for num=(Cable_Num_of_Sec*floor((i-1)/seg)+1):Num_Cable
            if Sum_D_Cable(num,2*i+1)<0
                F(num,2*i+1)=-F_Cable(num,2*i+1)+F_Cable(num,2*i)-F_f_Dn_Cj_R{num,2*i}(1)-F_f_Dn_Cj_L{num,2*i}(1);
            elseif Sum_D_Cable(num,2*+1)>0
                F(num,2*i+1)=-F_Cable(num,2*i+1)+F_Cable(num,2*i)+F_f_Dn_Cj_R{num,2*i}(1)+F_f_Dn_Cj_L{num,2*i}(1);
            else
                F(num,2*i+1)=-F_Cable(num,2*i+1)+F_Cable(num,2*i);
            end
        end     
    end 
end
for ii=1:Num_Cable
    F(ii,2*seg*(floor((ii-1)/Cable_Num_of_Sec)+1)+1)=0;
end
end