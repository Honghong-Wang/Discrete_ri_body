function F=modvec1(beta,num_cable)
temp4_1=Vector1(beta,num_cable);
temp3_1=[temp4_1(1) temp4_1(2) temp4_1(3)];
F=norm(temp3_1,2);
end