function F=Fun_Beta_Delete(beta0,record)
[m,n]=size(record);
normal=[0];
tf=isequal(record,normal);
if tf
    F=beta0;
else
    for del=1:n
        beta0(record(del)-del+1)=[];
    end  
    F=beta0;
end
end