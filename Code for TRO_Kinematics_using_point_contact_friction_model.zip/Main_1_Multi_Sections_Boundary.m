clc;clear all;
tic;% 
%% global
global sec seg Num_Cable Cable_Num_of_Sec h L E Iz g beta_boundary M_Disk M_Joint;
global theta_cable r_cable theta_bevel P1;
global F_Sensor F_Load M_Load
%% parameters 1：
sec=2;%section number,you can change the value (but you need to consider the parameters of cable numbers)
seg=4;%segment number,you can change the value
Cable_Num_of_Sec=3;%cables for each section
Num_Cable=Cable_Num_of_Sec*sec;% total cable number
d=0.8/1000;%diameter of rod
h=12/1000;%disk thickness
L=6/1000;%rod length
E=60E9;%
Iz=pi*d^4/64;%rod Iz
g=9.8066;%g N/kg
theta_bevel=7.5/180*pi;%bevel angle
beta_boundary=15/180*pi;%limited angle
m_disk_back=2.5/1000;% disk mass kg(no cables)
m_joint_back=0.5/1000;%joint mass（no rods）
m_disk_front=2.1/1000;
m_joint_front=0.4/1000;
rho_rod=6.45*1000;%（kg/m3）,6.45g/cm3 （length:16mm）
L_rod=16/1000;%16mm
rho_cable=2.0/125.27;%cable:g/mm=kg/m：(0.6mm)
%% parameters 2：
M_Disk=zeros(1,2*sec*seg);
M_Joint=zeros(1,2*sec*seg);
for ii=1:2 % Back Stage
    for jj=1:2*seg
        %Disk Mass---------------------------------------------
        M_Disk(1,2*seg*(ii-1)+jj)=m_disk_back+3*(sec+1-ii)*rho_cable*h;
        %Joint Mass---------------------------------------------
        M_Joint(1,2*seg*(ii-1)+jj)=m_joint_back+2*rho_rod*pi*d^2*L_rod/4;
    end
end
for ii=3:4 % Front Stage
    for jj=1:2*seg
        %Disk Mass---------------------------------------------
        M_Disk(1,2*seg*(ii-1)+jj)=m_disk_front+3*(sec+1-ii)*rho_cable*h;
        %Joint Mass---------------------------------------------
        M_Joint(1,2*seg*(ii-1)+jj)=m_joint_front+2*rho_rod*pi*d^2*L_rod/4;
    end
end
r_cable=[7.25 7.25 7.25 7.25 7.25 7.25 6.25 6.25 6.25 6.25 6.25 6.25]/1000;%radius of cables
theta_cable=[60 210 320 30 140 240 45 145 305 125 225 325]/180*pi;%angle of cables
%% External Load
F_Load=zeros(3,2*sec*seg);
M_Load=zeros(3,2*sec*seg);
% F_Load(2,2*sec*seg)=-0.0005*1;% Load (if needed)
%% Init：
%% F_Cable=zeros(Num_Cable,2*seg*seg);
F_Sensor=g*[0 1 0;
            0 1 0;
            0 0 0;
            0 0 0]';%tension on force sensors,you can change the values!
F_Cable0=zeros(Num_Cable,2*sec*seg);
for i=1:Num_Cable
   for j=1:2*seg*(floor((i-1)/Cable_Num_of_Sec)+1)
       F_Cable0(i,j)=F_Sensor(i);
   end
end
% * * * 0 0 0 0 0 0 
% * * * * * * 0 0 0
% * * * * * * * * *
%--------------------------------------------------------------------------
beta0=zeros(1,2*sec*seg+1);
options = optimoptions(@fsolve,'Display','iter','Algorithm', 'levenberg-marquardt','MaxFunEvals',...
    Inf,'StepTolerance',1e-10,'TolX',1e-10,'FunctionTolerance',1e-10);
%% Solution：
cycle=10;%iteration number
for temp=1:cycle
    [F_Cable,fval_2]=fsolve('Fun_F_Cable_4',F_Cable0,options,beta0);%solve force
    [beta0,fval_1]=fsolve('Kinetostatics_3',beta0,options,F_Cable);%solve angles, without joint constraint
end
%% consider joint constraint
[beta1,record]=Fun_Beta_Boundary(beta0);
disp(record);
if sum(record)==0
    loopCircular;
else 
    while (1)
        for temp=1:cycle
            [F_Cable,fval_2]=fsolve('Fun_F_Cable_4',F_Cable0,options,beta1);
            beta0=Fun_Beta_Delete(beta1,record);
            [beta0,fval_1]=fsolve('Kinetostatics_4',beta0,options,F_Cable,record,beta1);
            beta1=Fun_Beta_Add(beta0,record,beta1);
        end
        [beta_judge,record_judge]=Fun_Beta_Boundary(beta1);
        disp(record_judge);
        tf=isequal(record,record_judge);
        if tf
            break;
        else
            record=record_judge;
            beta1=beta_judge;
        end       
    end
end
toc;%time out
%% Display：
disp(record);
disp(beta1);% final angle result
%% Plot：