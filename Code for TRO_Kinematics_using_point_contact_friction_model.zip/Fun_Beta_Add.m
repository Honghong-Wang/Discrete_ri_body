function F=Fun_Beta_Add(beta0,record,beta1)
[m,n]=size(record);
normal=[0];
tf=isequal(record,normal);
if tf
    F=beta0;
else
    for i=1:n
        beta0=[beta0(1,1:record(i)-1) beta1(record(i)) beta0(1,record(i):end)];
    end
    F=beta0;
end
end